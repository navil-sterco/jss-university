<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
         Schema::table('page_sections', function (Blueprint $table) {
            if (!Schema::hasColumn('page_sections', 'group_key')) {
                $table->uuid('group_key')->nullable()->after('page_id');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('page_sections', function (Blueprint $table) {
            if (Schema::hasColumn('page_sections', 'group_key')) {
                $table->dropColumn('group_key');
            }
        });
    }
};
